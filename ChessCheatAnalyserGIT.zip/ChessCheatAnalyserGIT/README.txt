"C:\Users\ha0\source\repos\hao\ChessCheatAnalyser\bin\Debug\net6.0-windows\Data\stockfish_15_win_x64_avx2\stockfish_15.1_win_x64_avx2\stockfish-windows-2022-x86-64-avx2.exe"
Paste your engine here