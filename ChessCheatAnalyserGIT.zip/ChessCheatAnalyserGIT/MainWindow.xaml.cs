﻿using pax.chess;
using pax.uciChessEngine;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Cache;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Text.Json;
using System.Windows.Xps.Serialization;
using System.Xml.Linq;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Net.NetworkInformation;
using System.Net;
using System.Globalization;
using System.Security.Policy;
using System.Threading;
using System.IO;
using System.Text.RegularExpressions;

namespace ChessCheatAnalyser
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //Checking internet connection
            Theory.IsChecked = CheckInternetConnection(3000, "https://explorer.lichess.ovh/masters?play=e2e4");
            if (!(bool)Theory.IsChecked)
            {
                Theory.IsEnabled = false;
            }
        }
        private bool CheckInternetConnection(int timeoutMs, string url)
        {
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(url);
                request.KeepAlive = false;
                request.Timeout = timeoutMs;
                using (var response = (HttpWebResponse)request.GetResponse())
                    return true;
            }
            catch
            {
                return false;
            }
        }
        private async void UploadButtonClick(object sender, RoutedEventArgs e)
        {
            Load.Value = 0;
            Game game = Pgn.MapString("");
            try
            {
                game = Pgn.MapString(PGNBox.Text);
            }
            catch (Exception e2)
            {

            }
            int.TryParse(DepthBox.Text, out int depth);
            if (depth == 0) depth = 12;
            string[] moves = NNtoLAN(game);
            Load.Maximum = moves.Length;
            int result = await CalculatePlayer("Stockfish", @"C:\Users\ha0\source\repos\hao\ChessCheatAnalyser\bin\Debug\net6.0-windows\Data\stockfish_15_win_x64_avx2\stockfish_15.1_win_x64_avx2\stockfish-windows-2022-x86-64-avx2.exe", !PlayerB.IsChecked, moves, depth);
            WhiteResults.Text = $"{result} centipawns";
        }
        private async void T1TN_Click(object sender, RoutedEventArgs e)
        {
            Load.Value = 0;
            Game game = Pgn.MapString(PGNBox.Text);
            int.TryParse(DepthBox.Text, out int depth);
            if (depth == 0) depth = 12;
            string[] moves = NNtoLAN(game);
            Load.Maximum = moves.Length;
            var result = await CalculateT1TN("Stockfish", @"C:\Users\ha0\source\repos\hao\ChessCheatAnalyser\bin\Debug\net6.0-windows\Data\stockfish_15_win_x64_avx2\stockfish_15.1_win_x64_avx2\stockfish-windows-2022-x86-64-avx2.exe", !PlayerB.IsChecked, moves, depth);

            T1TN_tableresults.Columns.Clear();
            T1TNClass t1 = new T1TNClass(result[6], result[5], result.GetRange(0, 5));
            List<int> percent = result.GetRange(0, 5);
            for (int i = 0; i < percent.Count; i++)
            {
                percent[i] = percent[i] * 100 / (moves.Length / 2);
            }
            T1TNClass t2percent = new T1TNClass(result[6] * 100 / (moves.Length / 2), result[5] * 100 / (moves.Length / 2), percent);
            Debug.WriteLine($"{result[5]} * 100 / {(moves.Length / 2)} = {result[5] * 100 / (moves.Length / 2)}");

            ObservableCollection<T1TNClass> t1s = new ObservableCollection<T1TNClass>();
            t1s.Add(t1);
            t1s.Add(t2percent);

            T1TN_tableresults.ItemsSource = t1s;
        }
        public string FixPGN(string pgn)
        {
            Regex regex1 = new Regex("[a-h]1[NBRQ]");
            Regex regex8 = new Regex("[a-h]8[NBRQ]");
            MatchCollection matches1 = regex1.Matches(pgn);
            MatchCollection matches8 = regex8.Matches(pgn);

            Console.WriteLine();
            for (int k = 0; k < matches1.Count; k++)
            {
                List<char> move = new List<char>(matches1[k].Value);
                pgn = Regex.Replace(pgn, "[a-h]1[NBRQ]", $"{move[0]}{move[1]}={move[2]}");
            }
            for (int m = 0; m < matches8.Count; m++)
            {
                List<char> move = new List<char>(matches8[m].Value);
                pgn = Regex.Replace(pgn, "[a-h]8[NBRQ]", $"{move[0]}{move[1]}={move[2]}");
            }
            return pgn;
        }
        public async Task<int> HandlePGNArchive() //stirng path
        {
            string pgngames = "";
            using (StreamWriter sw = new StreamWriter(@"C:\Users\ha0\KURSACH\fairresults.txt", true)) //куда 
            {
                sw.WriteLine("Centipawns;Theory;None;T1;T2;T3;T4;T5;Elo;Player;White;Result;Game;");
            }
            List<string> evPlayerNames = new List<string>();
            /*evPlayerNames.Add("AP_Gaming123");
            evPlayerNames.Add("MooNFTkey2");
            evPlayerNames.Add("JuliusVai");
            evPlayerNames.Add("DrYesV2");
            evPlayerNames.Add("Cinnam0nroll");
            evPlayerNames.Add("DraculaPro1222");
            evPlayerNames.Add("FattytheYellowGhost");
            evPlayerNames.Add("mypooisredd");
            evPlayerNames.Add("Rocky_or_wot");*/
            evPlayerNames.Add("konstantin1245");
            evPlayerNames.Add("ha0q");

            using (StreamReader sr = new StreamReader(@"C:\Users\ha0\KURSACH\fairdatabase.pgn")) //откуда
            {
                pgngames = sr.ReadToEnd();
            }
            string[] gamesStr = pgngames.Split("[Event ");
            for (int j = 0; j < gamesStr.Length; j++)
            {
                if (gamesStr[j] != null && j != 0)
                {
                    gamesStr[j] = $"[Event {gamesStr[j]}";
                }
            }
            Console.WriteLine();
            List<Game> games = new List<Game>();
            for (int i = 0; i < gamesStr.Length; i++)
            {
                if (gamesStr[i] != "" && gamesStr[i] != null )//&& gamesStr[i].Contains("[TimeControl \"600+0\"]")
                {
                    try
                    {
                        //gamesStr[i] = FixPGN(gamesStr[i]);
                        Game game = Pgn.MapString(gamesStr[i]);
                        int.TryParse(game.Infos["WhiteElo"], out int whiteElo);
                        int.TryParse(game.Infos["BlackElo"], out int blackElo);
                        if (game.State.Moves.Count != 0 && Math.Abs(whiteElo - blackElo) < 450 && whiteElo < 2400)
                        {
                            games.Add(game);
                        }
                    }
                    catch (ArgumentOutOfRangeException e)
                    {
                        Debug.WriteLine("EEE");
                    }
                }
                else
                {
                    Debug.WriteLine("nulllll");
                }
                if (games.Count >= 378)
                {
                    break;
                }
            }

            Console.WriteLine();
            Stopwatch sw1 = Stopwatch.StartNew();
            for (int n = 0; n < games.Count; n++)
            {
                bool? isWhite = null;
                string white = games[n].Infos["White"];
                string black = games[n].Infos["Black"];
                foreach(string name in evPlayerNames)
                {
                    if(name.ToLower() == white.ToLower())
                    {
                        isWhite = true;
                    }
                    else if (evPlayerNames.Contains(black))
                    {
                        isWhite = false;
                    }
                    else
                    {
                        Debug.WriteLine($"    Player not finded... ({white.ToLower()} vs {black.ToLower()})");
                        continue;
                    }
                }
                
                double moves = Math.Ceiling((double)games[n].State.Moves.Count / 2);
                int centipawns = await CalculatePlayer("Stockfish", @"C:\Users\ha0\source\repos\hao\ChessCheatAnalyser\bin\Debug\net6.0-windows\Data\stockfish_15_win_x64_avx2\stockfish_15.1_win_x64_avx2\stockfish-windows-2022-x86-64-avx2.exe", isWhite, NNtoLAN(games[n]), 18);
                var t1tn = await CalculateT1TN("Stockfish", @"C:\Users\ha0\source\repos\hao\ChessCheatAnalyser\bin\Debug\net6.0-windows\Data\stockfish_15_win_x64_avx2\stockfish_15.1_win_x64_avx2\stockfish-windows-2022-x86-64-avx2.exe", isWhite, NNtoLAN(games[n]), 18);
                using (StreamWriter sw = new StreamWriter(@"C:\Users\ha0\KURSACH\fairresults.txt", true)) //куда
                {
                    StringBuilder sb = new StringBuilder();
                    sb.Append($"{centipawns};");
                    Console.WriteLine();
                    sb.Append($"{Math.Round(t1tn[6] / moves, 3)};{Math.Round(t1tn[5] / moves, 3)};");
                    for (int g = 0; g < t1tn.GetRange(0, 5).Count; g++)
                    {
                        sb.Append($"{Math.Round(t1tn.GetRange(0, 5)[g] / moves, 3)};");
                    }
                    if((bool)isWhite)
                    {
                        sb.Append($"{games[n].Infos["WhiteElo"]};");
                    }
                    else
                    {
                        sb.Append($"{games[n].Infos["BlackElo"]};");
                    }
                    string playerName = (bool)isWhite ? white : black;
                    //string playerName = games[n].Infos["White"];
                    sb.Append($"{playerName};");
                    sb.Append($"{(bool)isWhite};");
                    sb.Append($"{games[n].Infos["Result"]};");
                    
                    using (StreamReader sr = new StreamReader(@"C:\Users\ha0\KURSACH\cp_analysis.txt"))
                    {
                        sb.Append(sr.ReadToEnd());
                    }
                    using (StreamWriter sw2 = new StreamWriter(@"C:\Users\ha0\KURSACH\cp_analysis.txt", false))
                    {
                        sw2.Write("");
                    }
                    sw.WriteLine(sb.ToString());
                }
                Console.WriteLine();
            }
            sw1.Stop();
            Debug.WriteLine($"Ended with time: {sw1.Elapsed}");
            return 0;
        }
        public async Task<List<int>> CalculateT1TN(string name, string binary, bool? isWhite, string[] moves, int depth)
        {
            Engine engine = new Engine(name, binary);
            await engine.Start();
            var options = await engine.GetOptions();
            await engine.SetOption("MultiPV", 5);
            if ((bool)Threads.IsChecked)
            {
                await engine.SetOption("Threads", "12");
            }

            bool exceptTheory = (bool)Theory.IsChecked;
            bool stoppedTheory = false;
            List<int> T1TN = new List<int>();

            for (int i = 0; i < 7; i++)
            {
                T1TN.Add(0);
            }
            for (int i = 0; i < moves.Length; i++)
            {
                if ((bool)isWhite)
                {
                    if (i % 2 == 0) //white to move
                    {
                        if (exceptTheory)
                        {
                            bool isTheory = false;
                            if (!stoppedTheory)
                            {
                                isTheory = await IsTheoretical(moves[0..i]);
                            }
                            if (!isTheory)
                            {
                                if (!stoppedTheory)
                                {
                                    stoppedTheory = true;
                                    Debug.WriteLine("theory stop");
                                }
                                int a = await AnalyseT1TN(engine, moves[0..i], 5, moves[i], depth);
                                T1TN[a]++;
                            }
                            else
                            {
                                T1TN[6]++;
                            }
                        }
                        else
                        {

                            T1TN[await AnalyseT1TN(engine, moves[0..i], 5, moves[i], depth)]++;
                        }
                        Load.Value += 2;
                    }
                }
                else
                {
                    if (i % 2 != 0) //black to move
                    {
                        if (exceptTheory)
                        {
                            bool isTheory = false;
                            if (!stoppedTheory)
                            {
                                isTheory = await IsTheoretical(moves[0..i]);
                            }
                            if (!isTheory)
                            {
                                if (!stoppedTheory)
                                {
                                    stoppedTheory = true;
                                    Debug.WriteLine("theory stop");
                                }
                                int a = await AnalyseT1TN(engine, moves[0..i], 5, moves[i], depth);
                                T1TN[a]++;
                            }
                            else
                            {
                                T1TN[6]++;
                            }
                        }
                        else
                        {
                            T1TN[await AnalyseT1TN(engine, moves[0..i], 5, moves[i], depth)]++;
                        }
                        Load.Value += 2;
                    }
                }
            }
            engine.Stop();
            return T1TN;
        }
        public string[] NNtoLAN(Game game) //Utility
        {
            List<string> moves = new List<string>();
            foreach (Move move in game.State.Moves)
            {
                List<char> verticals = new List<char>();
                verticals.Add('a');
                verticals.Add('b');
                verticals.Add('c'); //FIX
                verticals.Add('d');
                verticals.Add('e');
                verticals.Add('f');
                verticals.Add('g');
                verticals.Add('h');
                StringBuilder sb = new StringBuilder();
                sb.Append(verticals[move.OldPosition.X]);
                sb.Append(move.OldPosition.Y + 1);
                sb.Append(verticals[move.NewPosition.X]);
                sb.Append(move.NewPosition.Y + 1);
                moves.Add(sb.ToString());
            }
            return moves.ToArray();
        }
        public bool AreEquals(string[] list1, string[] list2)
        {
            if (list1.Length != list2.Length) return false;
            bool areEqual = true;
            for (int i = 0; i < list1.Length; i++)
            {
                if (list1[i] != list2[i]) areEqual = false;
            }
            return areEqual;
        }
        public async Task<int> AnalyseCentipawnsRestart(Engine engine, string[] moves, int depth, string moveP, int i)
        {
            StringBuilder send = new StringBuilder();
            send.Append("position startpos moves ");
            foreach (string move in moves[0..i])
            {
                send.Append(move + " ");
            }
            await engine.Send(send.ToString());

            await engine.Send("ucinewgame");
            await engine.Send($"go depth {depth}");
            await Task.Delay(1000);
            var info = engine.GetInfo();
            await engine.Send("stop");
            //Debug.WriteLine($"Bestmove - {info.BestMove}");

            await engine.Send("ucinewgame");
            await engine.Send($"go depth {depth} searchmoves {info.BestMove.ToString()}");
            await Task.Delay(1000);
            var infoC = engine.GetInfo();
            await engine.Send("stop");
            //Debug.WriteLine($"Eval - {infoC.Evaluation}");

            await engine.Send("ucinewgame");
            await engine.Send($"go depth {depth} searchmoves {moveP}");
            await Task.Delay(1000);
            var infoP = engine.GetInfo();
            await engine.Send("stop");
            ///Debug.WriteLine($"Player move - {moveP}");
            //Debug.WriteLine($"CP loss = {infoC.Evaluation} - {infoP.Evaluation} = {infoC.Evaluation - infoP.Evaluation}");
            //Debug.WriteLine("");

            double winPercentC = 50 + 50 * (2 / (1 + Math.Exp(-0.00368208 * infoC.Evaluation)) - 1);
            double winPercentP = 50 + 50 * (2 / (1 + Math.Exp(-0.00368208 * infoP.Evaluation)) - 1);
            double accuracyPercent = 103.1668 * Math.Exp(-0.04354 * (winPercentC - winPercentP)) - 3.1669;

            var comboLine = infoC.PvInfos.ElementAt(0).Moves;
            EngineMove[] comboEngine = comboLine.ToArray();
            List<string> comboStr = new List<string>();
            for (int k = 0; k < comboEngine.Length; k++)
            {
                comboStr.Add(comboEngine[k].ToString());
            }
            Console.WriteLine();
            for (int j = i + comboLine.Count; j > i; j--)
            {
                if(j > moves.Length)
                {
                    j = moves.Length;
                }
                try
                {
                    var movesCut = moves[i..j];
                    comboStr = comboStr.GetRange(0, movesCut.Length);
                    string[] arrayCombo = comboStr.ToArray();
                    bool why = AreEquals(arrayCombo, movesCut);

                    if (why)
                    {
                        if (arrayCombo.Length > 2)
                        {//Сидим чекаем работает или нет надо проверять еще ыыыы
                            Debug.WriteLine($"Combo {arrayCombo.Length / 2} ({arrayCombo.Length} moves)!!!");
                        }
                        break;
                    }
                }
                catch (Exception)
                {
                    Debug.WriteLine($"i {i} j {j}");
                    throw;
                }
            }
            if (infoC.Mate != 0 || Math.Abs(infoC.Evaluation) > 1000)
            {
                using (StreamWriter sw = new StreamWriter(@"C:\Users\ha0\KURSACH\cp_analysis.txt", true)) //куда
                {
                    sw.Write($"0;");
                }
                return 0;
            }
            if (Math.Abs(infoC.Evaluation - infoP.Evaluation) > 1000)
            {
                using (StreamWriter sw = new StreamWriter(@"C:\Users\ha0\KURSACH\cp_analysis.txt", true)) //куда
                {
                    sw.Write($"1000;");
                }
                return 1000;
            }
            using (StreamWriter sw = new StreamWriter(@"C:\Users\ha0\KURSACH\cp_analysis.txt", true)) //куда
            {
                sw.Write($"{Math.Abs(infoC.Evaluation - infoP.Evaluation)};");
            }
            return Math.Abs(infoC.Evaluation - infoP.Evaluation);
        }
        public async Task<int> AnalyseT1TN(Engine engine, string[] moves, int N, string analyzedMove, int depth)
        {

            StringBuilder send = new StringBuilder();
            send.Append("position startpos moves ");
            foreach (string move in moves)
            {
                send.Append(move + " ");
            }
            await engine.Send(send.ToString());

            Stopwatch sw2 = Stopwatch.StartNew();
            await engine.Send($"go depth {depth}");

            await Task.Delay(1000); //here asd adadawdasdas ahsjkd nbakjsdb iadbwabu diaksdj ask 
            await engine.Send("stop");
            var info1 = engine.GetInfo();

            Console.WriteLine();

            if (info1.PvInfos == null)
            {
                throw new Exception();
            }
            for (int i = 0; i < info1.PvInfos.Count; i++)
            {
                if (info1.PvInfos.ElementAt<PvInfo>(i).Moves.ElementAt<EngineMove>(0).ToString() == analyzedMove)
                {
                    sw2.Stop();
                    Debug.WriteLine($"{i}");
                    return i;
                }
            }
            sw2.Stop();
            Debug.WriteLine(sw2.Elapsed);
            return N;
        }
        public async Task<int> CalculatePlayer(string name, string binary, bool? isWhite, string[] moves, int depth)
        {
            Stopwatch sw0 = Stopwatch.StartNew();
            Engine engine = new Engine(name, binary);
            await engine.Start();
            var options = await engine.GetOptions();
            if ((bool)Threads.IsChecked)
            {
                await engine.SetOption("Threads", "12");
            }
            bool exceptTheory = (bool)Theory.IsChecked;
            bool stoppedTheory = false;
            int allCPloss = 0;
            int divideBy = 0;
            for (int i = 0; i < moves.Length; i++)
            {
                if ((i % 2 == 0 && (bool)isWhite) || (i % 2 != 0 && !(bool)isWhite))
                {
                    int result = 0;
                    if (exceptTheory)
                    {
                        bool isTheory = false;
                        if (!stoppedTheory)
                        {
                            isTheory = await IsTheoretical(moves[0..i]);
                        }
                        if (!isTheory)
                        {
                            if (!stoppedTheory)
                            {
                                stoppedTheory = true;
                                Debug.WriteLine("theory stop");
                            }
                            result = await AnalyseCentipawnsRestart(engine, moves, depth, moves[i], i);
                            Debug.WriteLine($"{i / 2 + 1}. {result}");

                            allCPloss += result;
                            divideBy++;
                        }

                    }
                    else
                    {
                        result = await AnalyseCentipawnsRestart(engine, moves, depth, moves[i], i);
                        Debug.WriteLine(result);

                        allCPloss += result;
                        divideBy++;

                    }
                    Load.Value += 2;
                }
            }
            allCPloss /= divideBy;

            sw0.Stop();
            Debug.WriteLine($"AllTime: {sw0.Elapsed}");
            engine.Stop();
            return allCPloss;
        }
        public async Task<bool> IsTheoretical(string[] moves)
        {
            HttpClient client = new HttpClient();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < moves.Length; i++)
            {
                sb.Append(moves[i]);
                if (i != moves.Length - 1) sb.Append(",");
            }
            string movesURI = sb.ToString();
            Debug.WriteLine(movesURI);
            Debut debut;
            await Task.Delay(1000);
            try
            {
                var message = await client.GetStringAsync($"https://explorer.lichess.ovh/masters?play={movesURI}");
                debut = JsonSerializer.Deserialize<Debut>(message);
            }
            catch (ArgumentNullException e)
            {
                Debug.WriteLine(e.Message);
                throw;
            }
            int playedPos = 0;
            foreach (MoveD move in debut.moves)
            {
                playedPos += (move.black + move.white + move.draws);
            }
            if (playedPos > 32)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private async void handle_Click(object sender, RoutedEventArgs e)
        {
            await HandlePGNArchive();
            Console.WriteLine();
        }
    }
}