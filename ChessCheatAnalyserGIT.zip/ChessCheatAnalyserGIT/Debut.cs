﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessCheatAnalyser
{
    internal class Debut
    {
        public List<MoveD> moves { get; set; }
        public Opening opening { get; set; }
    }
    public class Opening
    {
        public string eco { get; set; }
        public string name { get; set; }
    }
    public class MoveD
    {
        public string uci { get; set; }
        public int averageRating { get; set; }
        public int white { get; set; }
        public int draws { get; set; }
        public int black { get; set; }
    }
}
