﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessCheatAnalyser
{
    internal class T1TNClass
    {
        public int Theory { get; set; }
        public int Non { get; set; }
        public int T1 { get; set; }
        public int T2 { get; set; }
        public int T3 { get; set; }
        public int T4 { get; set; }
        public int T5 { get; set; }
        public T1TNClass(int theory, int non, List<int> t1tn)
        {
            Theory = theory;
            Non = non;
            T1 = t1tn[0];
            T2 = t1tn[1];
            T3 = t1tn[2];
            T4 = t1tn[3];
            T5 = t1tn[4];
        }
    }
}
